def add_one(num):
    num += 1
    return num
